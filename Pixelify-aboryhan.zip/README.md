# Pixelify-Android-O
This magisk module modifies your build.prop so you the Play Store recognizes your device as Pixel XL to download ALL Daydream apps.

## How to activate
1. Download and install the module
2. Activate the module in Magisk Manager (Always use the latest version.)
3. Reboot to see the changes

After reboot your device model will be changed to Pixel XL and then you can download all the apps of Daydream.